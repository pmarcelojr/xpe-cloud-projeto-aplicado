def obter_horario_brasilia_iso8601():
    return "2023-09-13"
