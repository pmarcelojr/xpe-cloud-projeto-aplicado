import sys
from loguru import logger
from Helpers.utils import obter_horario_brasilia_iso8601

FORMAT = '[{extra[data]} |{level}| arquivo: {file}, linha: {line}] {message}'

def get_logger():
    logger.remove()
    logger.add(
        sys.stderr,
        format=FORMAT,
        backtrace=True,
        diagnose=True,
        level='INFO',
    )
    logger_context = logger.patch(
            lambda record: record['extra'].update(
                    data=obter_horario_brasilia_iso8601()
                )
        )
    
    return logger_context
