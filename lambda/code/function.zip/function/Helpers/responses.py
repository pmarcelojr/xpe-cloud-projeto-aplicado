from os import environ

def get_retorno_sucesso():
    return {
        'statusCode': 200,
        'headers': {
            "Content-Type": "application/json"
        },
        "body": {
            "Region": environ['AWS_REGION']
        }
    }
    
def get_retorno_erro():
    return {
        'statusCode': 500,
        'headers': {
            "Content-Type": "application/json"
        },
        "body": {
            "Region": environ['AWS_REGION']
        }
    }
