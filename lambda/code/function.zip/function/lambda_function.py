from os import environ
from time import time
import boto3
from botocore.exceptions import ClientError

start_time = time()


def lambda_handler(event, context):
    # TODO implement
    glue_client = boto3.client('glue')
    workflow_name = ""
    
    print(f"Evento recebido: {event}")
    print(f"Contexto recebido: {context}")
    print(f"Tempo de execucao: {time() - start_time}")
    
    nome_bucket = event['Records'][0]['s3']['bucket']['name']
    nome_arquivo = event['Records'][0]['s3']['object']['key']
    print(f"Bucket {nome_bucket} - Arquivo: {nome_arquivo}")
    
    if "tbs0mh10" in nome_arquivo:
        workflow_name = "movimento_aplicacao_processado"
    elif "tbs0mh20" in nome_arquivo:
        workflow_name = "movimento_resgate_processado"
        
    if not workflow_name:
        print(f"## Nome do arquivo nao previsto")
    else:
        response = glue_client.start_workflow_run(
                Name=workflow_name,
                RunProperties={
                    'nome_arquivo': nome_arquivo
                }
            )
        print(f"## STARTED GLUE JOB: {workflow_name}")
        print(f"## WORKFLOW RUN ID: {response['RunId']}")
    
    end_time = time()
    tempo_decorrido = end_time - start_time
    print(f"Tempo de execucao: {tempo_decorrido}")
    
    return get_retorno_sucesso()


def get_retorno_sucesso():
    return {
        'statusCode': 200,
        'headers': {
            "Content-Type": "application/json"
        },
        "body": {
            "Region": environ['AWS_REGION']
        }
    }
    
    
def get_retorno_erro():
    return {
        'statusCode': 500,
        'headers': {
            "Content-Type": "application/json"
        },
        "body": {
            "Region": environ['AWS_REGION']
        }
    }
