from os import environ
from time import time
import boto3
from botocore.exceptions import ClientError

from Helpers.responses import get_retorno_sucesso, get_retorno_erro
from Helpers.logger import get_logger

start_time = time()
logger = get_logger()

def lambda_handler(event, context):
    # TODO implement
    glue_client = boto3.client('glue')
    workflow_name = ""
    
    logger.info(f"Evento recebido: {event}")
    logger.info(f"Contexto recebido: {context}")
    logger.info(f"Tempo de execucao: {time() - start_time}")
    
    nome_bucket = event['Records'][0]['s3']['bucket']['name']
    nome_arquivo = event['Records'][0]['s3']['object']['key']
    logger.info(f"Bucket {nome_bucket} - Arquivo: {nome_arquivo}")
    
    if "tbs0mh10" in nome_arquivo:
        workflow_name = "movimento_aplicacao_processado"
    elif "tbs0mh20" in nome_arquivo:
        workflow_name = "movimento_resgate_processado"
        
    if not workflow_name:
        logger.info(f"## Nome do arquivo nao previsto")
    else:
        response = glue_client.start_workflow_run(
                Name=workflow_name,
                RunProperties={
                    'nome_arquivo': nome_arquivo
                }
            )
        logger.info(f"## STARTED GLUE JOB: {workflow_name}")
        logger.info(f"## WORKFLOW RUN ID: {response['RunId']}")
    
    end_time = time()
    tempo_decorrido = end_time - start_time
    logger.info(f"Tempo de execucao: {tempo_decorrido}")
    
    return get_retorno_sucesso()
